import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:test2/coffe_type.dart';
import 'package:test2/tile.dart';

class home extends StatefulWidget {
  @override
  State<home> createState() => _homeState();
}

class _homeState extends State<home> {
  final List cofeeType = [
    [
      'Cappucino',
      true,
    ],
    [
      'Coffe',
      false,
    ],
    [
      'Latte',
      false,
    ],
    ['Tea', false]
  ];

  void selectedFunciton(int index) {
    setState(() {
      for (int i = 0; i < cofeeType.length; i++) {
        cofeeType[i][1] = false;
      }

      cofeeType[index][1] = true;
    });
  }

  // const home({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[900],
      appBar: AppBar(
        title: Text(
          "By Eng Fatih Jimale",
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        leading: Icon(Icons.menu),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Icon(Icons.person),
          ),
        ],
      ),
      body: Column(
        children: [
          SizedBox(
            height: 50,
          ),
          Center(
            child: Text("waligey ma qoslin ilaa aan coffee cabo",
                style:
                    GoogleFonts.bebasNeue(fontSize: 30, color: Colors.white)),
          ),
          SizedBox(
            height: 50,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: TextField(
              decoration: InputDecoration(
                  prefixIcon: Icon(Icons.search),
                  hintText: "Search for best Coffee...",
                  hintStyle: TextStyle(color: Colors.white),
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade600)),
                  enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade600))),
            ),
          ),
          SizedBox(
            height: 100,
          ),
          ////// coffe names...............
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 10),
            child: Container(
                padding: EdgeInsets.all(10),
                height: 50,
                // width: MediaQuery.of(context).size.width,
                child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: cofeeType.length,
                    itemBuilder: (context, index) {
                      return CoffeType(
                        cofeeType: cofeeType[index][0],
                        isSelected: cofeeType[index][1],
                        onTap: () {
                          selectedFunciton(index);
                        },
                      );
                    })

                // child: ,
                ),
          ),
          Expanded(
              child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              tile(
                imagePath: "lib/images/c.jpg",
                cofName: "Coffee",
                cofAdd: "caano Ari",
                cofPrice: "3.00",
              ),
              tile(
                imagePath: "lib/images/cof4.jpg",
                cofName: "Coffee",
                cofAdd: "caano Lo'o",
                cofPrice: "5.00",
              ),
              tile(
                imagePath: "lib/images/cof.jpeg",
                cofName: "Coffee",
                cofAdd: "caano Geel",
                cofPrice: "7.00",
              ),
            ],
          )),

          Padding(
            padding:
                const EdgeInsets.symmetric(vertical: 12.0, horizontal: 8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "BY: ENG FAITH JIMALE",
                  style: TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                      color: Colors.white),
                ),
                Text(
                  "DATE DEVELOPED: 15 AUG 2023",
                  style: TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                      color: Colors.white),
                ),
                Text(
                  "CONTACT: +252 613 80 78 87",
                  style: TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                      color: Colors.white),
                ),
                // ],
                // )
                // )
              ],
            ),
          )
        ],
      ),
    );

    //  Column(
    //   children: [Text("hello")],
    // );
  }
}
