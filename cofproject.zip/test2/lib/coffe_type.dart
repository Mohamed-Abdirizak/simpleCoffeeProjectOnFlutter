import 'package:flutter/material.dart';

class CoffeType extends StatelessWidget {
  // const CoffeType({super.key});
  final String cofeeType;
  final bool isSelected;
  final VoidCallback onTap;
  CoffeType(
      {required this.cofeeType, required this.isSelected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: this.onTap,
      child: Padding(
        padding: const EdgeInsets.only(left: 25.0, right: 35),
        child: Text(
          this.cofeeType,
          style: TextStyle(
              fontSize: 25,
              color: isSelected ? Colors.orange : Colors.white,
              fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
