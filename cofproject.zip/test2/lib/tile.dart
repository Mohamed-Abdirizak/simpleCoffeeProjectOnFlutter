import 'package:flutter/material.dart';

class tile extends StatelessWidget {
  // const tile({super.key});
  final String imagePath;
  final String cofName;
  final String cofAdd;
  final String cofPrice;
  // final String cof
  tile(
      {required this.imagePath,
      required this.cofName,
      required this.cofAdd,
      required this.cofPrice});

  // @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(20.0),
          child: Container(
            width: 250,
            decoration: BoxDecoration(
                color: Colors.black54, borderRadius: BorderRadius.circular(12)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  // cofee image text...
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.asset(
                      imagePath,
                      // height: ,
                      fit: BoxFit.cover,
                      height: 300,
                      width: 300,
                    ),
                  ),
                ),
                // Padding(
                // padding: const EdgeInsets.only(bottom: 8.0),
                // child:
                // Column(
                // crossAxisAlignment: CrossAxisAlignment.start,
                // children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    cofName,
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    cofAdd,
                    style: TextStyle(fontSize: 20, color: Colors.white70),
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "\$" + cofPrice,
                        style: TextStyle(fontSize: 20, color: Colors.white),
                      ),
                      Container(
                          padding: EdgeInsets.all(8),
                          decoration: BoxDecoration(
                              color: Colors.orange,
                              borderRadius: BorderRadius.circular(12)),
                          child: Icon(Icons.add)),
                    ],
                  ),
                )

                //     ],
                //   ),
                // ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
